STORK-A README:

In the downloadable zip folder we have included a spreadsheet test-samples.xlsx" and folder called "test-images". The test-images folder includes 18 images of embryos for testing the API. The spreadsheet, test-samples.xlsx includes all relevant clinical information for each test embryo image (patient age, blastocyst score, ICM Score, TE Score, Expansion Score, and morphokinetics from tPnF-tSB.

To use STORK-A, drag or select an image from the test-images folder. At minimum, the platform requires the use of an image. Additional clinical information can be added and the platform will select the appropriate model to predict ploidy status given the input information.

Once all images and associated clinical information have been inputted, hit the "SUBMIT" button. The platform will produce three results:
	1) Abnormal vs Normal classification 
	2) Complex Aneuploid vs Euploid Classification
	3) Complex Aneuploid vs Not Complex Aneuploid Classification
Each of the results will include the class prediction along with probabilities for each class.

